export { default } from './CardContent';
