export { default } from './Notice';
